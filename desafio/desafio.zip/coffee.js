module.exports = {
  async pour() {
    console.log("Colocando café");
  },
};
