module.exports = {
  async pour() {
    console.log("Servindo suco no copo");
  },
};
